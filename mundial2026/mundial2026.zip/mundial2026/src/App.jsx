import { useState } from "react";

// ── TRANSLATIONS ──────────────────────────────────────────────────────────────
const T = {
  es: {
    title: "FIFA WORLD CUP 26",
    subtitle: "Seguimiento Oficial del Torneo",
    groups: "GRUPOS",
    knockout: "ELIMINATORIAS",
    calendar: "CALENDARIO",
    stats: "ESTADÍSTICAS",
    autoFill: "Auto",
    manual: "Manual",
    pts: "Pts", pj: "PJ", pg: "PG", pe: "PE", pp: "PP",
    gf: "GF", gc: "GC", dg: "DG", team: "Equipo", group: "Grupo",
    round32: "Octavos de Final", round16: "Cuartos de Final",
    semis: "Semifinales", final: "Final", winner: "CAMPEÓN",
    saveScore: "Guardar", editScore: "Editar", score: "Resultado",
    vs: "vs", advancesTop2: "Top 2 de cada grupo + 8 mejores terceros clasifican",
    autoFilling: "Llenando...", dataLoaded: "¡Datos cargados!", resetData: "Reiniciar",
    confirmReset: "¿Reiniciar todos los datos?", topScorers: "Goleadores",
    addGoal: "Agregar", playerName: "Jugador", noScorers: "Sin goleadores aún",
    totalGoals: "Goles Totales", totalMatches: "Partidos Jugados",
    avgGoals: "Promedio x Partido", teamsAdvanced: "Equipos Clasif.",
    today: "HOY", upcoming: "Próximos", played: "Jugados",
    allMatches: "Todos", filterGroup: "Filtrar por grupo",
    matchday1: "Jornada 1", matchday2: "Jornada 2", matchday3: "Jornada 3",
    knockoutRound: "Eliminatoria", allGroups: "Todos los grupos",
    venue: "Estadio", time: "Hora ET",
  },
  en: {
    title: "FIFA WORLD CUP 26",
    subtitle: "Official Tournament Tracker",
    groups: "GROUPS",
    knockout: "KNOCKOUT",
    calendar: "SCHEDULE",
    stats: "STATS",
    autoFill: "Auto",
    manual: "Manual",
    pts: "Pts", pj: "MP", pg: "W", pe: "D", pp: "L",
    gf: "GF", gc: "GA", dg: "GD", team: "Team", group: "Group",
    round32: "Round of 16", round16: "Quarter-Finals",
    semis: "Semi-Finals", final: "Final", winner: "CHAMPION",
    saveScore: "Save", editScore: "Edit", score: "Score",
    vs: "vs", advancesTop2: "Top 2 from each group + 8 best 3rd-place teams advance",
    autoFilling: "Filling...", dataLoaded: "Data loaded!", resetData: "Reset",
    confirmReset: "Reset all data?", topScorers: "Top Scorers",
    addGoal: "Add", playerName: "Player", noScorers: "No scorers yet",
    totalGoals: "Total Goals", totalMatches: "Matches Played",
    avgGoals: "Goals per Match", teamsAdvanced: "Teams Advanced",
    today: "TODAY", upcoming: "Upcoming", played: "Played",
    allMatches: "All", filterGroup: "Filter by group",
    matchday1: "Matchday 1", matchday2: "Matchday 2", matchday3: "Matchday 3",
    knockoutRound: "Knockout", allGroups: "All groups",
    venue: "Venue", time: "Time ET",
  },
};

// ── FULL SCHEDULE DATA ────────────────────────────────────────────────────────
const SCHEDULE = [
  // JORNADA 1
  { id:1,  date:"2026-06-11", time:"3:00 PM", group:"A", home:"México",         homeF:"🇲🇽", away:"Sudáfrica",       awayF:"🇿🇦", venue:"Mexico City",    md:1 },
  { id:2,  date:"2026-06-11", time:"10:00 PM",group:"A", home:"Corea del Sur",  homeF:"🇰🇷", away:"Chequia",         awayF:"🇨🇿", venue:"Guadalajara",    md:1 },
  { id:3,  date:"2026-06-12", time:"3:00 PM", group:"B", home:"Canadá",         homeF:"🇨🇦", away:"Bosnia-Herz.",    awayF:"🇧🇦", venue:"Toronto",        md:1 },
  { id:4,  date:"2026-06-12", time:"9:00 PM", group:"D", home:"Estados Unidos", homeF:"🇺🇸", away:"Paraguay",        awayF:"🇵🇾", venue:"Los Angeles",    md:1 },
  { id:5,  date:"2026-06-13", time:"3:00 PM", group:"B", home:"Qatar",          homeF:"🇶🇦", away:"Suiza",           awayF:"🇨🇭", venue:"San Francisco",  md:1 },
  { id:6,  date:"2026-06-13", time:"6:00 PM", group:"C", home:"Brasil",         homeF:"🇧🇷", away:"Marruecos",       awayF:"🇲🇦", venue:"New York/NJ",    md:1 },
  { id:7,  date:"2026-06-13", time:"9:00 PM", group:"C", home:"Haití",          homeF:"🇭🇹", away:"Escocia",         awayF:"🏴󠁧󠁢󠁳󠁣󠁴󠁿", venue:"Boston",         md:1 },
  { id:8,  date:"2026-06-13", time:"12:00 AM",group:"D", home:"Australia",      homeF:"🇦🇺", away:"Turquía",         awayF:"🇹🇷", venue:"Vancouver",      md:1 },
  { id:9,  date:"2026-06-14", time:"1:00 PM", group:"E", home:"Alemania",       homeF:"🇩🇪", away:"Curazao",         awayF:"🇨🇼", venue:"Houston",        md:1 },
  { id:10, date:"2026-06-14", time:"4:00 PM", group:"F", home:"Países Bajos",   homeF:"🇳🇱", away:"Japón",           awayF:"🇯🇵", venue:"Dallas",         md:1 },
  { id:11, date:"2026-06-14", time:"7:00 PM", group:"E", home:"Costa de Marfil",homeF:"🇨🇮", away:"Ecuador",         awayF:"🇪🇨", venue:"Philadelphia",   md:1 },
  { id:12, date:"2026-06-14", time:"10:00 PM",group:"F", home:"Túnez",          homeF:"🇹🇳", away:"Suecia",          awayF:"🇸🇪", venue:"Monterrey",      md:1 },
  { id:13, date:"2026-06-15", time:"12:00 PM",group:"H", home:"España",         homeF:"🇪🇸", away:"Cabo Verde",      awayF:"🇨🇻", venue:"Atlanta",        md:1 },
  { id:14, date:"2026-06-15", time:"3:00 PM", group:"G", home:"Bélgica",        homeF:"🇧🇪", away:"Egipto",          awayF:"🇪🇬", venue:"Seattle",        md:1 },
  { id:15, date:"2026-06-15", time:"6:00 PM", group:"H", home:"Arabia Saudita", homeF:"🇸🇦", away:"Uruguay",         awayF:"🇺🇾", venue:"Miami",          md:1 },
  { id:16, date:"2026-06-15", time:"9:00 PM", group:"G", home:"Irán",           homeF:"🇮🇷", away:"Nueva Zelanda",   awayF:"🇳🇿", venue:"Los Angeles",    md:1 },
  { id:17, date:"2026-06-16", time:"3:00 PM", group:"I", home:"Francia",        homeF:"🇫🇷", away:"Senegal",         awayF:"🇸🇳", venue:"New York/NJ",    md:1 },
  { id:18, date:"2026-06-16", time:"6:00 PM", group:"I", home:"Irak",           homeF:"🇮🇶", away:"Noruega",         awayF:"🇳🇴", venue:"Boston",         md:1 },
  { id:19, date:"2026-06-16", time:"9:00 PM", group:"J", home:"Argentina",      homeF:"🇦🇷", away:"Argelia",         awayF:"🇩🇿", venue:"Kansas City",    md:1 },
  { id:20, date:"2026-06-16", time:"12:00 AM",group:"J", home:"Austria",        homeF:"🇦🇹", away:"Jordania",        awayF:"🇯🇴", venue:"San Francisco",  md:1 },
  { id:21, date:"2026-06-17", time:"1:00 PM", group:"K", home:"Portugal",       homeF:"🇵🇹", away:"R.D. Congo",      awayF:"🇨🇩", venue:"Houston",        md:1 },
  { id:22, date:"2026-06-17", time:"4:00 PM", group:"L", home:"Inglaterra",     homeF:"🏴󠁧󠁢󠁥󠁮󠁧󠁿", away:"Croacia",         awayF:"🇭🇷", venue:"Dallas",         md:1 },
  { id:23, date:"2026-06-17", time:"7:00 PM", group:"L", home:"Ghana",          homeF:"🇬🇭", away:"Panamá",          awayF:"🇵🇦", venue:"Toronto",        md:1 },
  { id:24, date:"2026-06-17", time:"10:00 PM",group:"K", home:"Uzbekistán",     homeF:"🇺🇿", away:"Colombia",        awayF:"🇨🇴", venue:"Mexico City",    md:1 },
  // JORNADA 2
  { id:25, date:"2026-06-18", time:"12:00 PM",group:"A", home:"Chequia",        homeF:"🇨🇿", away:"Sudáfrica",       awayF:"🇿🇦", venue:"Atlanta",        md:2 },
  { id:26, date:"2026-06-18", time:"3:00 PM", group:"B", home:"Suiza",          homeF:"🇨🇭", away:"Bosnia-Herz.",    awayF:"🇧🇦", venue:"Los Angeles",    md:2 },
  { id:27, date:"2026-06-18", time:"6:00 PM", group:"B", home:"Canadá",         homeF:"🇨🇦", away:"Qatar",           awayF:"🇶🇦", venue:"Vancouver",      md:2 },
  { id:28, date:"2026-06-18", time:"9:00 PM", group:"A", home:"México",         homeF:"🇲🇽", away:"Corea del Sur",   awayF:"🇰🇷", venue:"Guadalajara",    md:2 },
  { id:29, date:"2026-06-19", time:"3:00 PM", group:"D", home:"Estados Unidos", homeF:"🇺🇸", away:"Australia",       awayF:"🇦🇺", venue:"Seattle",        md:2 },
  { id:30, date:"2026-06-19", time:"3:00 PM", group:"C", home:"Escocia",        homeF:"🏴󠁧󠁢󠁳󠁣󠁴󠁿", away:"Marruecos",       awayF:"🇲🇦", venue:"Boston",         md:2 },
  { id:31, date:"2026-06-19", time:"9:00 PM", group:"C", home:"Brasil",         homeF:"🇧🇷", away:"Haití",           awayF:"🇭🇹", venue:"Philadelphia",   md:2 },
  { id:32, date:"2026-06-19", time:"12:00 AM",group:"D", home:"Turquía",        homeF:"🇹🇷", away:"Paraguay",        awayF:"🇵🇾", venue:"San Francisco",  md:2 },
  { id:33, date:"2026-06-20", time:"1:00 PM", group:"F", home:"Países Bajos",   homeF:"🇳🇱", away:"Suecia",          awayF:"🇸🇪", venue:"Houston",        md:2 },
  { id:34, date:"2026-06-20", time:"4:00 PM", group:"E", home:"Alemania",       homeF:"🇩🇪", away:"Costa de Marfil", awayF:"🇨🇮", venue:"Toronto",        md:2 },
  { id:35, date:"2026-06-20", time:"8:00 PM", group:"E", home:"Ecuador",        homeF:"🇪🇨", away:"Curazao",         awayF:"🇨🇼", venue:"Kansas City",    md:2 },
  { id:36, date:"2026-06-20", time:"12:00 AM",group:"F", home:"Túnez",          homeF:"🇹🇳", away:"Japón",           awayF:"🇯🇵", venue:"Monterrey",      md:2 },
  { id:37, date:"2026-06-21", time:"12:00 PM",group:"H", home:"España",         homeF:"🇪🇸", away:"Arabia Saudita",  awayF:"🇸🇦", venue:"Atlanta",        md:2 },
  { id:38, date:"2026-06-21", time:"3:00 PM", group:"G", home:"Bélgica",        homeF:"🇧🇪", away:"Irán",            awayF:"🇮🇷", venue:"Los Angeles",    md:2 },
  { id:39, date:"2026-06-21", time:"6:00 PM", group:"H", home:"Uruguay",        homeF:"🇺🇾", away:"Cabo Verde",      awayF:"🇨🇻", venue:"Miami",          md:2 },
  { id:40, date:"2026-06-21", time:"9:00 PM", group:"G", home:"Nueva Zelanda",  homeF:"🇳🇿", away:"Egipto",          awayF:"🇪🇬", venue:"Vancouver",      md:2 },
  { id:41, date:"2026-06-22", time:"1:00 PM", group:"J", home:"Argentina",      homeF:"🇦🇷", away:"Austria",         awayF:"🇦🇹", venue:"Dallas",         md:2 },
  { id:42, date:"2026-06-22", time:"5:00 PM", group:"I", home:"Francia",        homeF:"🇫🇷", away:"Irak",            awayF:"🇮🇶", venue:"Philadelphia",   md:2 },
  { id:43, date:"2026-06-22", time:"8:00 PM", group:"I", home:"Noruega",        homeF:"🇳🇴", away:"Senegal",         awayF:"🇸🇳", venue:"New York/NJ",    md:2 },
  { id:44, date:"2026-06-22", time:"11:00 PM",group:"J", home:"Jordania",       homeF:"🇯🇴", away:"Argelia",         awayF:"🇩🇿", venue:"San Francisco",  md:2 },
  { id:45, date:"2026-06-23", time:"1:00 PM", group:"K", home:"Portugal",       homeF:"🇵🇹", away:"Uzbekistán",      awayF:"🇺🇿", venue:"Houston",        md:2 },
  { id:46, date:"2026-06-23", time:"4:00 PM", group:"L", home:"Inglaterra",     homeF:"🏴󠁧󠁢󠁥󠁮󠁧󠁿", away:"Ghana",           awayF:"🇬🇭", venue:"Dallas",         md:2 },
  { id:47, date:"2026-06-23", time:"7:00 PM", group:"L", home:"Croacia",        homeF:"🇭🇷", away:"Panamá",          awayF:"🇵🇦", venue:"New York/NJ",    md:2 },
  { id:48, date:"2026-06-23", time:"10:00 PM",group:"K", home:"R.D. Congo",     homeF:"🇨🇩", away:"Colombia",        awayF:"🇨🇴", venue:"Atlanta",        md:2 },
  // JORNADA 3
  { id:49, date:"2026-06-25", time:"3:00 PM", group:"A", home:"Sudáfrica",      homeF:"🇿🇦", away:"Corea del Sur",   awayF:"🇰🇷", venue:"Kansas City",    md:3 },
  { id:50, date:"2026-06-25", time:"3:00 PM", group:"A", home:"Chequia",        homeF:"🇨🇿", away:"México",          awayF:"🇲🇽", venue:"Guadalajara",    md:3 },
  { id:51, date:"2026-06-25", time:"9:00 PM", group:"B", home:"Qatar",          homeF:"🇶🇦", away:"Bosnia-Herz.",    awayF:"🇧🇦", venue:"Seattle",        md:3 },
  { id:52, date:"2026-06-25", time:"9:00 PM", group:"B", home:"Suiza",          homeF:"🇨🇭", away:"Canadá",          awayF:"🇨🇦", venue:"Dallas",         md:3 },
  { id:53, date:"2026-06-26", time:"3:00 PM", group:"C", home:"Marruecos",      homeF:"🇲🇦", away:"Haití",           awayF:"🇭🇹", venue:"Atlanta",        md:3 },
  { id:54, date:"2026-06-26", time:"3:00 PM", group:"C", home:"Escocia",        homeF:"🏴󠁧󠁢󠁳󠁣󠁴󠁿", away:"Brasil",          awayF:"🇧🇷", venue:"Boston",         md:3 },
  { id:55, date:"2026-06-26", time:"9:00 PM", group:"D", home:"Paraguay",       homeF:"🇵🇾", away:"Australia",       awayF:"🇦🇺", venue:"Miami",          md:3 },
  { id:56, date:"2026-06-26", time:"9:00 PM", group:"D", home:"Turquía",        homeF:"🇹🇷", away:"Estados Unidos",  awayF:"🇺🇸", venue:"Los Angeles",    md:3 },
  { id:57, date:"2026-06-27", time:"3:00 PM", group:"E", home:"Alemania",       homeF:"🇩🇪", away:"Ecuador",         awayF:"🇪🇨", venue:"Philadelphia",   md:3 },
  { id:58, date:"2026-06-27", time:"3:00 PM", group:"E", home:"Costa de Marfil",homeF:"🇨🇮", away:"Curazao",         awayF:"🇨🇼", venue:"Toronto",        md:3 },
  { id:59, date:"2026-06-27", time:"7:30 PM", group:"K", home:"R.D. Congo",     homeF:"🇨🇩", away:"Uzbekistán",      awayF:"🇺🇿", venue:"Atlanta",        md:3 },
  { id:60, date:"2026-06-27", time:"9:00 PM", group:"F", home:"Japón",          homeF:"🇯🇵", away:"Suecia",          awayF:"🇸🇪", venue:"Houston",        md:3 },
  { id:61, date:"2026-06-27", time:"9:00 PM", group:"F", home:"Túnez",          homeF:"🇹🇳", away:"Países Bajos",    awayF:"🇳🇱", venue:"New York/NJ",    md:3 },
  { id:62, date:"2026-06-28", time:"3:00 PM", group:"G", home:"Egipto",         homeF:"🇪🇬", away:"Irán",            awayF:"🇮🇷", venue:"Los Angeles",    md:3 },
  { id:63, date:"2026-06-28", time:"3:00 PM", group:"G", home:"Bélgica",        homeF:"🇧🇪", away:"Nueva Zelanda",   awayF:"🇳🇿", venue:"Vancouver",      md:3 },
  { id:64, date:"2026-06-28", time:"9:00 PM", group:"H", home:"España",         homeF:"🇪🇸", away:"Uruguay",         awayF:"🇺🇾", venue:"Dallas",         md:3 },
  { id:65, date:"2026-06-28", time:"9:00 PM", group:"H", home:"Cabo Verde",     homeF:"🇨🇻", away:"Arabia Saudita",  awayF:"🇸🇦", venue:"Kansas City",    md:3 },
  { id:66, date:"2026-06-29", time:"3:00 PM", group:"I", home:"Senegal",        homeF:"🇸🇳", away:"Irak",            awayF:"🇮🇶", venue:"San Francisco",  md:3 },
  { id:67, date:"2026-06-29", time:"3:00 PM", group:"I", home:"Noruega",        homeF:"🇳🇴", away:"Francia",         awayF:"🇫🇷", venue:"Boston",         md:3 },
  { id:68, date:"2026-06-29", time:"9:00 PM", group:"J", home:"Argelia",        homeF:"🇩🇿", away:"Austria",         awayF:"🇦🇹", venue:"Miami",          md:3 },
  { id:69, date:"2026-06-29", time:"9:00 PM", group:"J", home:"Jordania",       homeF:"🇯🇴", away:"Argentina",       awayF:"🇦🇷", venue:"Seattle",        md:3 },
  { id:70, date:"2026-06-30", time:"3:00 PM", group:"K", home:"Colombia",       homeF:"🇨🇴", away:"Portugal",        awayF:"🇵🇹", venue:"Houston",        md:3 },
  { id:71, date:"2026-06-30", time:"3:00 PM", group:"L", home:"Ghana",          homeF:"🇬🇭", away:"Croacia",         awayF:"🇭🇷", venue:"Philadelphia",   md:3 },
  { id:72, date:"2026-06-30", time:"9:00 PM", group:"L", home:"Panamá",         homeF:"🇵🇦", away:"Inglaterra",      awayF:"🏴󠁧󠁢󠁥󠁮󠁧󠁿", venue:"New York/NJ",    md:3 },
  { id:73, date:"2026-06-30", time:"9:00 PM", group:"K", home:"Uzbekistán",     homeF:"🇺🇿", away:"Portugal",        awayF:"🇵🇹", venue:"Dallas",         md:3 },
  // ELIMINATORIAS (Octavos)
  { id:74, date:"2026-06-28", time:"3:00 PM",  group:"KO", home:"1A",  homeF:"⚽", away:"2B",  awayF:"⚽", venue:"SoFi Stadium, LA",   md:0, round:"R32" },
  { id:75, date:"2026-06-29", time:"1:00 PM",  group:"KO", home:"1C",  homeF:"⚽", away:"2F",  awayF:"⚽", venue:"NRG Houston",         md:0, round:"R32" },
  { id:76, date:"2026-06-29", time:"4:30 PM",  group:"KO", home:"1E",  homeF:"⚽", away:"3rd", awayF:"⚽", venue:"Gillette, Boston",    md:0, round:"R32" },
  { id:77, date:"2026-06-29", time:"9:00 PM",  group:"KO", home:"1F",  homeF:"⚽", away:"2C",  awayF:"⚽", venue:"BBVA, Monterrey",     md:0, round:"R32" },
  { id:78, date:"2026-06-30", time:"1:00 PM",  group:"KO", home:"2E",  homeF:"⚽", away:"2I",  awayF:"⚽", venue:"AT&T, Dallas",        md:0, round:"R32" },
  { id:79, date:"2026-06-30", time:"5:00 PM",  group:"KO", home:"1I",  homeF:"⚽", away:"3rd", awayF:"⚽", venue:"MetLife, NJ",         md:0, round:"R32" },
  { id:80, date:"2026-06-30", time:"9:00 PM",  group:"KO", home:"1A",  homeF:"⚽", away:"3rd", awayF:"⚽", venue:"Azteca, Mex City",    md:0, round:"R32" },
  { id:81, date:"2026-07-01", time:"12:00 PM", group:"KO", home:"1L",  homeF:"⚽", away:"3rd", awayF:"⚽", venue:"Benz, Atlanta",       md:0, round:"R32" },
  { id:82, date:"2026-07-01", time:"4:00 PM",  group:"KO", home:"1G",  homeF:"⚽", away:"3rd", awayF:"⚽", venue:"Lumen, Seattle",      md:0, round:"R32" },
  { id:83, date:"2026-07-01", time:"8:00 PM",  group:"KO", home:"1D",  homeF:"⚽", away:"3rd", awayF:"⚽", venue:"Levi's, S.F.",        md:0, round:"R32" },
  { id:84, date:"2026-07-02", time:"3:00 PM",  group:"KO", home:"1H",  homeF:"⚽", away:"2J",  awayF:"⚽", venue:"SoFi Stadium, LA",    md:0, round:"R32" },
  { id:85, date:"2026-07-02", time:"7:00 PM",  group:"KO", home:"2K",  homeF:"⚽", away:"2L",  awayF:"⚽", venue:"BMO, Toronto",        md:0, round:"R32" },
  { id:86, date:"2026-07-02", time:"11:00 PM", group:"KO", home:"1B",  homeF:"⚽", away:"3rd", awayF:"⚽", venue:"BC Place, Vancouver", md:0, round:"R32" },
  { id:87, date:"2026-07-03", time:"2:00 PM",  group:"KO", home:"2D",  homeF:"⚽", away:"2G",  awayF:"⚽", venue:"Arrowhead, KC",       md:0, round:"R32" },
  { id:88, date:"2026-07-03", time:"7:00 PM",  group:"KO", home:"2H",  homeF:"⚽", away:"2A",  awayF:"⚽", venue:"Hard Rock, Miami",    md:0, round:"R32" },
  { id:89, date:"2026-07-04", time:"3:00 PM",  group:"KO", home:"1J",  homeF:"⚽", away:"1K",  awayF:"⚽", venue:"AT&T, Dallas",        md:0, round:"R32" },
  // Cuartos
  { id:90, date:"2026-07-07", time:"3:00 PM",  group:"KO", home:"W74", homeF:"⚽", away:"W75", awayF:"⚽", venue:"MetLife, NJ",         md:0, round:"QF" },
  { id:91, date:"2026-07-07", time:"7:00 PM",  group:"KO", home:"W76", homeF:"⚽", away:"W77", awayF:"⚽", venue:"SoFi, LA",            md:0, round:"QF" },
  { id:92, date:"2026-07-08", time:"3:00 PM",  group:"KO", home:"W78", homeF:"⚽", away:"W79", awayF:"⚽", venue:"Arrowhead, KC",       md:0, round:"QF" },
  { id:93, date:"2026-07-08", time:"7:00 PM",  group:"KO", home:"W80", homeF:"⚽", away:"W81", awayF:"⚽", venue:"AT&T, Dallas",        md:0, round:"QF" },
  { id:94, date:"2026-07-09", time:"3:00 PM",  group:"KO", home:"W82", homeF:"⚽", away:"W83", awayF:"⚽", venue:"Azteca, Mex City",    md:0, round:"QF" },
  { id:95, date:"2026-07-09", time:"7:00 PM",  group:"KO", home:"W84", homeF:"⚽", away:"W85", awayF:"⚽", venue:"NRG, Houston",        md:0, round:"QF" },
  { id:96, date:"2026-07-10", time:"3:00 PM",  group:"KO", home:"W86", homeF:"⚽", away:"W87", awayF:"⚽", venue:"Levi's, S.F.",        md:0, round:"QF" },
  { id:97, date:"2026-07-10", time:"7:00 PM",  group:"KO", home:"W88", homeF:"⚽", away:"W89", awayF:"⚽", venue:"BC Place, Vancouver", md:0, round:"QF" },
  // Semis
  { id:98, date:"2026-07-14", time:"3:00 PM",  group:"KO", home:"W90", homeF:"⚽", away:"W91", awayF:"⚽", venue:"MetLife, NJ",         md:0, round:"SF" },
  { id:99, date:"2026-07-14", time:"7:00 PM",  group:"KO", home:"W92", homeF:"⚽", away:"W93", awayF:"⚽", venue:"AT&T, Dallas",        md:0, round:"SF" },
  { id:100,date:"2026-07-15", time:"3:00 PM",  group:"KO", home:"W94", homeF:"⚽", away:"W95", awayF:"⚽", venue:"SoFi, LA",            md:0, round:"SF" },
  { id:101,date:"2026-07-15", time:"7:00 PM",  group:"KO", home:"W96", homeF:"⚽", away:"W97", awayF:"⚽", venue:"Azteca, Mex City",    md:0, round:"SF" },
  // Final
  { id:102,date:"2026-07-19", time:"3:00 PM",  group:"KO", home:"W98/99",homeF:"🏆", away:"W100/101",awayF:"🏆", venue:"MetLife, NJ", md:0, round:"FINAL" },
];

// ── INITIAL GROUP DATA ────────────────────────────────────────────────────────
const GROUPS_DATA = {
  A: { teams: ["México", "Corea del Sur", "Sudáfrica", "Chequia"],                flag: ["🇲🇽", "🇰🇷", "🇿🇦", "🇨🇿"] },
  B: { teams: ["Canadá", "Suiza", "Qatar", "Bosnia-Herz."],                       flag: ["🇨🇦", "🇨🇭", "🇶🇦", "🇧🇦"] },
  C: { teams: ["Brasil", "Marruecos", "Haití", "Escocia"],                        flag: ["🇧🇷", "🇲🇦", "🇭🇹", "🏴󠁧󠁢󠁳󠁣󠁴󠁿"] },
  D: { teams: ["Estados Unidos", "Paraguay", "Australia", "Turquía"],             flag: ["🇺🇸", "🇵🇾", "🇦🇺", "🇹🇷"] },
  E: { teams: ["Alemania", "Curazao", "Costa de Marfil", "Ecuador"],              flag: ["🇩🇪", "🇨🇼", "🇨🇮", "🇪🇨"] },
  F: { teams: ["Países Bajos", "Japón", "Suecia", "Túnez"],                       flag: ["🇳🇱", "🇯🇵", "🇸🇪", "🇹🇳"] },
  G: { teams: ["Bélgica", "Egipto", "Irán", "Nueva Zelanda"],                     flag: ["🇧🇪", "🇪🇬", "🇮🇷", "🇳🇿"] },
  H: { teams: ["España", "Cabo Verde", "Arabia Saudita", "Uruguay"],              flag: ["🇪🇸", "🇨🇻", "🇸🇦", "🇺🇾"] },
  I: { teams: ["Francia", "Senegal", "Irak", "Noruega"],                          flag: ["🇫🇷", "🇸🇳", "🇮🇶", "🇳🇴"] },
  J: { teams: ["Argentina", "Argelia", "Austria", "Jordania"],                    flag: ["🇦🇷", "🇩🇿", "🇦🇹", "🇯🇴"] },
  K: { teams: ["Portugal", "R.D. Congo", "Uzbekistán", "Colombia"],               flag: ["🇵🇹", "🇨🇩", "🇺🇿", "🇨🇴"] },
  L: { teams: ["Inglaterra", "Croacia", "Ghana", "Panamá"],                       flag: ["🏴󠁧󠁢󠁥󠁮󠁧󠁿", "🇭🇷", "🇬🇭", "🇵🇦"] },
};

function initGroupMatches(teams, flags) {
  const matches = [];
  for (let i = 0; i < teams.length; i++) {
    for (let j = i + 1; j < teams.length; j++) {
      matches.push({
        id: `${teams[i]}-${teams[j]}`,
        home: teams[i], homeFlag: flags[i],
        away: teams[j], awayFlag: flags[j],
        homeScore: null, awayScore: null,
        played: false, editing: false,
        tempHome: "", tempAway: "",
      });
    }
  }
  return matches;
}

function computeStandings(matches, teams, flags) {
  const stats = {};
  teams.forEach((t, i) => {
    stats[t] = { name: t, flag: flags[i], pj: 0, pg: 0, pe: 0, pp: 0, gf: 0, gc: 0, dg: 0, pts: 0 };
  });
  matches.filter(m => m.played).forEach(m => {
    const h = stats[m.home], a = stats[m.away];
    h.pj++; a.pj++;
    h.gf += m.homeScore; h.gc += m.awayScore;
    a.gf += m.awayScore; a.gc += m.homeScore;
    h.dg = h.gf - h.gc; a.dg = a.gf - a.gc;
    if (m.homeScore > m.awayScore) { h.pg++; h.pts += 3; a.pp++; }
    else if (m.homeScore === m.awayScore) { h.pe++; h.pts += 1; a.pe++; a.pts += 1; }
    else { a.pg++; a.pts += 3; h.pp++; }
  });
  return Object.values(stats).sort((a, b) => b.pts - a.pts || b.dg - a.dg || b.gf - a.gf);
}

function randScore() {
  const r = Math.random();
  if (r < 0.12) return [0, 0];
  if (r < 0.22) return [1, 0];
  if (r < 0.32) return [0, 1];
  if (r < 0.45) return [1, 1];
  if (r < 0.55) return [2, 1];
  if (r < 0.65) return [1, 2];
  if (r < 0.72) return [2, 0];
  if (r < 0.79) return [0, 2];
  if (r < 0.84) return [2, 2];
  if (r < 0.88) return [3, 1];
  if (r < 0.92) return [1, 3];
  return [3, 0];
}

// ── SCHEDULE LOOKUP (by "home|away") ─────────────────────────────────────────
const SCHEDULE_BY_TEAMS = {};
SCHEDULE.forEach(m => {
  SCHEDULE_BY_TEAMS[`${m.home}|${m.away}`] = m;
  SCHEDULE_BY_TEAMS[`${m.away}|${m.home}`] = m; // both directions
});

// Helper: short date label  e.g. "11 Jun" / "Jun 11"
function shortDate(dateStr, lang) {
  const d = new Date(dateStr + "T12:00:00");
  return d.toLocaleDateString(lang === "es" ? "es-ES" : "en-US", { day:"numeric", month:"short" });
}

// ── GROUP COLOR MAP ────────────────────────────────────────────────────────────
const GROUP_COLORS = {
  A:"#E61D25", B:"#2A398D", C:"#3CAC3B", D:"#FF8C00",
  E:"#9B59B6", F:"#00A8CC", G:"#E91E63", H:"#FFD700",
  I:"#00BCD4", J:"#8BC34A", K:"#FF5722", L:"#607D8B", KO:"#FFD700",
};

// ── MAIN ──────────────────────────────────────────────────────────────────────
export default function MundialApp() {
  const [lang, setLang] = useState("es");
  const t = T[lang];
  const [activeTab, setActiveTab] = useState("calendar");
  const [notification, setNotification] = useState("");

  const [groupMatches, setGroupMatches] = useState(() => {
    const gm = {};
    Object.entries(GROUPS_DATA).forEach(([g, d]) => { gm[g] = initGroupMatches(d.teams, d.flag); });
    return gm;
  });

  const [knockout, setKnockout] = useState({
    r32:  Array(16).fill(null).map((_, i) => ({ id:i, team1:null, team2:null, score1:null, score2:null, played:false })),
    r16:  Array(8).fill(null).map((_, i)  => ({ id:i, team1:null, team2:null, score1:null, score2:null, played:false })),
    semi: Array(4).fill(null).map((_, i)  => ({ id:i, team1:null, team2:null, score1:null, score2:null, played:false })),
    final:[{ id:0, team1:null, team2:null, score1:null, score2:null, played:false }],
    champion: null,
  });

  const [selectedGroup, setSelectedGroup] = useState("A");

  // Calendar filters
  const [calFilter, setCalFilter] = useState("all"); // all | upcoming | played
  const [calGroup, setCalGroup]   = useState("all"); // all | A-L | KO
  const [calMd,    setCalMd]      = useState("all"); // all | 1 | 2 | 3 | KO

  // Schedule scores state
  const [scheduleScores, setScheduleScores] = useState(() => {
    const s = {};
    SCHEDULE.forEach(m => { s[m.id] = { h: "", a: "", played: false, editing: false }; });
    return s;
  });

  function notify(msg) {
    setNotification(msg);
    setTimeout(() => setNotification(""), 2500);
  }

  const standings = {};
  Object.entries(groupMatches).forEach(([g, matches]) => {
    standings[g] = computeStandings(matches, GROUPS_DATA[g].teams, GROUPS_DATA[g].flag);
  });

  function saveGroupMatch(groupId, matchId, homeScore, awayScore) {
    setGroupMatches(prev => {
      const gm = { ...prev };
      gm[groupId] = gm[groupId].map(m =>
        m.id !== matchId ? m : { ...m, homeScore: parseInt(homeScore), awayScore: parseInt(awayScore), played:true, editing:false }
      );
      return gm;
    });
  }

  function startEdit(groupId, matchId) {
    setGroupMatches(prev => {
      const gm = { ...prev };
      gm[groupId] = gm[groupId].map(m =>
        m.id !== matchId ? m : { ...m, editing:true, tempHome: m.homeScore??'', tempAway: m.awayScore??'' }
      );
      return gm;
    });
  }

  async function doAutoFill() {
    notify(t.autoFilling);
    setGroupMatches(prev => {
      const gm = {};
      Object.entries(prev).forEach(([g, matches]) => {
        gm[g] = matches.map(m => {
          const [hs, as] = randScore();
          return { ...m, homeScore:hs, awayScore:as, played:true, editing:false };
        });
      });
      return gm;
    });
    setScheduleScores(prev => {
      const s = { ...prev };
      SCHEDULE.filter(m => m.group !== "KO").forEach(m => {
        const [h, a] = randScore();
        s[m.id] = { h, a, played:true, editing:false };
      });
      return s;
    });
    setTimeout(() => notify(t.dataLoaded), 400);
  }

  function doReset() {
    if (!window.confirm(t.confirmReset)) return;
    setGroupMatches(() => {
      const gm = {};
      Object.entries(GROUPS_DATA).forEach(([g, d]) => { gm[g] = initGroupMatches(d.teams, d.flag); });
      return gm;
    });
    setScheduleScores(() => {
      const s = {};
      SCHEDULE.forEach(m => { s[m.id] = { h:"", a:"", played:false, editing:false }; });
      return s;
    });
    setScorers([]);
    notify("✓ Reset");
  }

  // ── Calendar filtering ──────────────────────────────────────────────────────
  const TODAY = "2026-06-02";
  const filteredSchedule = SCHEDULE.filter(m => {
    const ss = scheduleScores[m.id];
    if (calFilter === "played"   && !ss.played) return false;
    if (calFilter === "upcoming" && ss.played)  return false;
    if (calGroup !== "all" && m.group !== calGroup) return false;
    if (calMd === "1" && m.md !== 1) return false;
    if (calMd === "2" && m.md !== 2) return false;
    if (calMd === "3" && m.md !== 3) return false;
    if (calMd === "KO" && m.group !== "KO") return false;
    return true;
  });

  // Group by date
  const byDate = {};
  filteredSchedule.forEach(m => {
    if (!byDate[m.date]) byDate[m.date] = [];
    byDate[m.date].push(m);
  });

  const ROUND_LABELS = { R32: t.round32, QF: t.round16, SF: t.semis, FINAL: t.final };

  // ── RENDER ────────────────────────────────────────────────────────────────
  return (
    <div style={S.root}>
      <div style={S.bgPattern} />
      {notification && <div style={S.notif}>{notification}</div>}

      {/* HEADER */}
      <header style={S.header}>
        <div style={S.hTop}>
          <div style={S.logo}>
            <span style={S.logoIcon}>⚽</span>
            <div>
              <div style={S.logoTitle}>{t.title}</div>
              <div style={S.logoSub}>{t.subtitle}</div>
            </div>
          </div>
          <div style={S.hCtrls}>
            <button style={S.langBtn} onClick={() => setLang(l => l==="es"?"en":"es")}>
              {lang==="es"?"🇺🇸 EN":"🇪🇸 ES"}
            </button>
            <button style={S.autoBtn} onClick={doAutoFill}>⚡ {t.autoFill}</button>
            <button style={S.resetBtn} onClick={doReset}>↺</button>
          </div>
        </div>
        <nav style={S.tabs}>
          {[
            { key:"calendar", label:t.calendar, icon:"📅" },
            { key:"groups",   label:t.groups,   icon:"▦"  },
            { key:"knockout", label:t.knockout, icon:"🏆" },
          ].map(tab => (
            <button key={tab.key}
              style={{ ...S.tab, ...(activeTab===tab.key ? S.tabA : {}) }}
              onClick={() => setActiveTab(tab.key)}>
              {tab.icon} {tab.label}
            </button>
          ))}
        </nav>
      </header>

      <main style={S.main}>

        {/* ── CALENDAR TAB ─────────────────────────────────────────────────── */}
        {activeTab === "calendar" && (
          <div>
            {/* Filter bar */}
            <div style={S.filterBar}>
              {/* Status filter */}
              <div style={S.filterRow}>
                {["all","upcoming","played"].map(f => (
                  <button key={f} style={{ ...S.filterBtn, ...(calFilter===f?S.filterBtnA:{}) }}
                    onClick={() => setCalFilter(f)}>
                    {f==="all" ? t.allMatches : f==="upcoming" ? t.upcoming : t.played}
                  </button>
                ))}
              </div>
              {/* Matchday filter */}
              <div style={S.filterRow}>
                {["all","1","2","3","KO"].map(f => (
                  <button key={f} style={{ ...S.filterBtn, ...(calMd===f?S.filterBtnA:{}) }}
                    onClick={() => setCalMd(f)}>
                    {f==="all"?"All" : f==="KO"?"Elim." : `J${f}`}
                  </button>
                ))}
              </div>
              {/* Group filter */}
              <div style={{ ...S.filterRow, flexWrap:"wrap" }}>
                <button style={{ ...S.filterBtn, ...(calGroup==="all"?S.filterBtnA:{}) }}
                  onClick={() => setCalGroup("all")}>Todos</button>
                {[...Object.keys(GROUPS_DATA),"KO"].map(g => (
                  <button key={g}
                    style={{ ...S.filterBtn, ...(calGroup===g?{ background:GROUP_COLORS[g], color:"#fff", border:"none" }:{}) }}
                    onClick={() => setCalGroup(g)}>{g}</button>
                ))}
              </div>
            </div>

            {/* Match cards by date */}
            {Object.keys(byDate).sort().map(date => (
              <div key={date}>
                <DateHeader date={date} today={TODAY} lang={lang} />
                {byDate[date].map(match => (
                  <CalendarMatchCard
                    key={match.id}
                    match={match}
                    ss={scheduleScores[match.id]}
                    t={t}
                    groupColor={GROUP_COLORS[match.group]}
                    roundLabel={match.round ? ROUND_LABELS[match.round] : `Grupo ${match.group} · J${match.md}`}
                    onEdit={() => setScheduleScores(prev => ({
                      ...prev, [match.id]: { ...prev[match.id], editing:true }
                    }))}
                    onSave={(h, a) => setScheduleScores(prev => ({
                      ...prev, [match.id]: { h, a, played:true, editing:false }
                    }))}
                    onChange={(field, val) => setScheduleScores(prev => ({
                      ...prev, [match.id]: { ...prev[match.id], [field]: val }
                    }))}
                  />
                ))}
              </div>
            ))}

            {filteredSchedule.length === 0 && (
              <div style={S.empty}>No hay partidos con estos filtros</div>
            )}
          </div>
        )}

        {/* ── GROUPS TAB ───────────────────────────────────────────────────── */}
        {activeTab === "groups" && (
          <div>
            <div style={S.groupSel}>
              {Object.keys(GROUPS_DATA).map(g => (
                <button key={g}
                  style={{ ...S.gTab, ...(selectedGroup===g?{ background:GROUP_COLORS[g], color:"#fff", border:`1px solid ${GROUP_COLORS[g]}` }:{}) }}
                  onClick={() => setSelectedGroup(g)}>{g}</button>
              ))}
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {/* Standings */}
              <div style={S.card}>
                <div style={S.cardH}>
                  <span style={{ ...S.badge, background:GROUP_COLORS[selectedGroup] }}>{t.group} {selectedGroup}</span>
                  <span style={S.cardTitle}>{GROUPS_DATA[selectedGroup].flag.join(" ")}</span>
                </div>
                <div style={{ overflowX:"auto" }}>
                  <table style={S.table}>
                    <thead>
                      <tr>
                        <th style={S.th}>#</th>
                        <th style={{ ...S.th, textAlign:"left" }}>{t.team}</th>
                        <th style={S.th}>{t.pj}</th>
                        <th style={S.th}>{t.pg}</th>
                        <th style={S.th}>{t.pe}</th>
                        <th style={S.th}>{t.pp}</th>
                        <th style={S.th}>{t.gf}</th>
                        <th style={S.th}>{t.gc}</th>
                        <th style={S.th}>{t.dg}</th>
                        <th style={{ ...S.th, color:"#FFD700" }}>{t.pts}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {standings[selectedGroup].map((team, i) => (
                        <tr key={team.name} style={{ background: i<2?"rgba(58,172,59,0.12)": i===2?"rgba(255,215,0,0.07)":"transparent" }}>
                          <td style={{ ...S.td, color: i<2?"#3CAC3B": i===2?"#FFD700":"#aaa" }}>{i+1}</td>
                          <td style={{ ...S.td, textAlign:"left" }}><span style={{marginRight:5}}>{team.flag}</span>{team.name}</td>
                          <td style={S.td}>{team.pj}</td>
                          <td style={S.td}>{team.pg}</td>
                          <td style={S.td}>{team.pe}</td>
                          <td style={S.td}>{team.pp}</td>
                          <td style={S.td}>{team.gf}</td>
                          <td style={S.td}>{team.gc}</td>
                          <td style={{ ...S.td, color: team.dg>0?"#3CAC3B": team.dg<0?"#E61D25":"#aaa" }}>
                            {team.dg>0?`+${team.dg}`:team.dg}
                          </td>
                          <td style={{ ...S.td, fontWeight:900, color:"#FFD700", fontSize:15 }}>{team.pts}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div style={{ padding:"6px 14px", fontSize:11, color:"#555" }}>
                  <span style={{color:"#3CAC3B"}}>■</span> Clasifican &nbsp;
                  <span style={{color:"#FFD700"}}>■</span> Posible 3ro
                </div>
              </div>
              {/* Group Matches */}
              <div style={S.card}>
                <div style={S.cardH}><span style={S.cardTitle}>Partidos del Grupo {selectedGroup}</span></div>
                {groupMatches[selectedGroup].map((match, idx) => {
                  const sched = SCHEDULE_BY_TEAMS[`${match.home}|${match.away}`];
                  return (
                  <div key={match.id} style={{ borderBottom: idx>0?"1px solid rgba(255,255,255,0.05)":"none", padding:"10px 14px" }}>
                    {/* Date/time chip */}
                    {sched && (
                      <div style={S.matchDateChip}>
                        <span style={S.matchDateDot} />
                        <span>{shortDate(sched.date, lang)}</span>
                        <span style={{color:"#555",margin:"0 4px"}}>·</span>
                        <span>{sched.time} ET</span>
                        <span style={{color:"#555",margin:"0 4px"}}>·</span>
                        <span style={{color:"#666"}}>📍 {sched.venue}</span>
                      </div>
                    )}
                    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                      <div style={{ flex:1, display:"flex", alignItems:"center", gap:5 }}>
                        <span style={{fontSize:17}}>{match.homeFlag}</span>
                        <span style={{fontSize:11, color:"#ccc"}}>{match.home}</span>
                      </div>
                      <div style={{ minWidth:72, textAlign:"center" }}>
                        {match.played && !match.editing ? (
                          <span style={S.scoreDisp}>{match.homeScore} – {match.awayScore}</span>
                        ) : match.editing ? (
                          <div style={{display:"flex",alignItems:"center",gap:4}}>
                            <input style={S.sInput} type="number" min="0" max="20" value={match.tempHome}
                              onChange={e => setGroupMatches(prev => {
                                const gm={...prev}; gm[selectedGroup]=gm[selectedGroup].map(m=>m.id===match.id?{...m,tempHome:e.target.value}:m); return gm;
                              })} />
                            <span style={{color:"#FFD700"}}>–</span>
                            <input style={S.sInput} type="number" min="0" max="20" value={match.tempAway}
                              onChange={e => setGroupMatches(prev => {
                                const gm={...prev}; gm[selectedGroup]=gm[selectedGroup].map(m=>m.id===match.id?{...m,tempAway:e.target.value}:m); return gm;
                              })} />
                          </div>
                        ) : (
                          <span style={{color:"#555",fontSize:12}}>{t.vs}</span>
                        )}
                      </div>
                      <div style={{ flex:1, display:"flex", alignItems:"center", gap:5, flexDirection:"row-reverse" }}>
                        <span style={{fontSize:17}}>{match.awayFlag}</span>
                        <span style={{fontSize:11, color:"#ccc"}}>{match.away}</span>
                      </div>
                    </div>
                    <div style={{ display:"flex", justifyContent:"center", marginTop:5 }}>
                      {match.editing ? (
                        <button style={S.btnSave} onClick={() => saveGroupMatch(selectedGroup, match.id, match.tempHome, match.tempAway)}>{t.saveScore}</button>
                      ) : match.played ? (
                        <button style={S.btnEdit} onClick={() => startEdit(selectedGroup, match.id)}>{t.editScore}</button>
                      ) : (
                        <button style={S.btnEdit} onClick={() => startEdit(selectedGroup, match.id)}>+ {t.score}</button>
                      )}
                    </div>
                  </div>
                  );
                })}
              </div>
            </div>
            <p style={{textAlign:"center",color:"#555",fontSize:11,marginTop:12}}>{t.advancesTop2}</p>
          </div>
        )}

        {/* ── KNOCKOUT TAB ─────────────────────────────────────────────────── */}
        {activeTab === "knockout" && (
          <KOBracket knockout={knockout} setKnockout={setKnockout} t={t} lang={lang} />
        )}


      </main>

      <footer style={S.footer}>WE ARE 26 · FIFA WORLD CUP™ · USA · CANADA · MEXICO</footer>
    </div>
  );
}

// ── DATE HEADER ───────────────────────────────────────────────────────────────
function DateHeader({ date, today, lang }) {
  const d = new Date(date + "T12:00:00");
  const isToday = date === today;
  const options = { weekday:"long", month:"long", day:"numeric" };
  const label = d.toLocaleDateString(lang==="es"?"es-ES":"en-US", options);
  return (
    <div style={S.dateHeader}>
      {isToday && <span style={S.todayBadge}>HOY</span>}
      <span style={{ textTransform:"capitalize", color: isToday?"#FFD700":"#bbb" }}>{label}</span>
    </div>
  );
}

// ── CALENDAR MATCH CARD ───────────────────────────────────────────────────────
function CalendarMatchCard({ match, ss, t, groupColor, roundLabel, onEdit, onSave, onChange }) {
  return (
    <div style={{ ...S.calCard, borderLeft:`3px solid ${groupColor}` }}>
      <div style={S.calTop}>
        <span style={{ ...S.calBadge, background: groupColor + "33", color: groupColor, border:`1px solid ${groupColor}55` }}>
          {roundLabel}
        </span>
        <span style={S.calTime}>🕐 {match.time} ET &nbsp;📍 {match.venue}</span>
      </div>
      <div style={S.calTeams}>
        <div style={S.calTeam}>
          <span style={S.calFlag}>{match.homeF}</span>
          <span style={S.calTeamName}>{match.home}</span>
        </div>
        <div style={S.calScore}>
          {ss.played && !ss.editing ? (
            <span style={S.scoreDisp}>{ss.h} – {ss.a}</span>
          ) : ss.editing ? (
            <div style={{display:"flex",alignItems:"center",gap:5}}>
              <input style={S.sInput} type="number" min="0" max="20" value={ss.h}
                onChange={e => onChange("h", e.target.value)} />
              <span style={{color:"#FFD700",fontWeight:900}}>–</span>
              <input style={S.sInput} type="number" min="0" max="20" value={ss.a}
                onChange={e => onChange("a", e.target.value)} />
            </div>
          ) : (
            <span style={{color:"#444",fontSize:13,fontWeight:700}}>{t.vs}</span>
          )}
        </div>
        <div style={{ ...S.calTeam, flexDirection:"row-reverse" }}>
          <span style={S.calFlag}>{match.awayF}</span>
          <span style={S.calTeamName}>{match.away}</span>
        </div>
      </div>
      <div style={{ display:"flex", justifyContent:"center", marginTop:6 }}>
        {ss.editing ? (
          <button style={S.btnSave} onClick={() => onSave(ss.h, ss.a)}>{t.saveScore}</button>
        ) : ss.played ? (
          <button style={S.btnEdit} onClick={onEdit}>{t.editScore}</button>
        ) : match.group !== "KO" ? (
          <button style={S.btnEdit} onClick={onEdit}>+ {t.score}</button>
        ) : (
          <span style={{fontSize:11,color:"#444"}}>Pendiente</span>
        )}
      </div>
    </div>
  );
}

// ── KNOCKOUT BRACKET ──────────────────────────────────────────────────────────
// Map knockout round keys to SCHEDULE round codes
const KO_ROUND_MAP = { r32:"R32", r16:"QF", semi:"SF", final:"FINAL" };

function KOBracket({ knockout, setKnockout, t, lang }) {
  const roundLabels = { r32:t.round32, r16:t.round16, semi:t.semis, final:t.final };

  // Pre-build ordered lists of KO schedule matches by round
  const koByRound = { R32:[], QF:[], SF:[], FINAL:[] };
  SCHEDULE.filter(m => m.group === "KO").forEach(m => {
    if (koByRound[m.round]) koByRound[m.round].push(m);
  });
  Object.values(koByRound).forEach(arr => arr.sort((a,b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time)));

  function KOMatch({ match, roundKey, i }) {
    const [editing, setEditing] = useState(false);
    const [t1,setT1]=useState(match.team1||"");
    const [t2,setT2]=useState(match.team2||"");
    const [s1,setS1]=useState(match.score1??"");
    const [s2,setS2]=useState(match.score2??"");

    // Find the corresponding schedule entry for this slot
    const roundCode = KO_ROUND_MAP[roundKey];
    const schedSlot = koByRound[roundCode]?.[i];

    function save() {
      if (!t1||!t2) return;
      setKnockout(prev => {
        const upd={...prev};
        upd[roundKey]=upd[roundKey].map((m,idx)=>idx===i?{...m,team1:t1,team2:t2,score1:parseInt(s1),score2:parseInt(s2),played:s1!==""}:m);
        return upd;
      });
      setEditing(false);
    }
    return (
      <div style={S.koMatch}>
        {/* Date chip */}
        {schedSlot && (
          <div style={S.koDateChip}>
            📅 {shortDate(schedSlot.date, lang)} · {schedSlot.time} ET · 📍 {schedSlot.venue}
          </div>
        )}
        {editing ? (
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            <input style={S.koInput} placeholder="Equipo 1" value={t1} onChange={e=>setT1(e.target.value)} />
            <div style={{display:"flex",alignItems:"center",gap:6,justifyContent:"center"}}>
              <input style={S.sInput} type="number" min="0" max="20" value={s1} onChange={e=>setS1(e.target.value)} placeholder="0"/>
              <span style={{color:"#FFD700"}}>–</span>
              <input style={S.sInput} type="number" min="0" max="20" value={s2} onChange={e=>setS2(e.target.value)} placeholder="0"/>
            </div>
            <input style={S.koInput} placeholder="Equipo 2" value={t2} onChange={e=>setT2(e.target.value)} />
            <button style={S.btnSave} onClick={save}>{t.saveScore}</button>
          </div>
        ) : (
          <div style={{cursor:"pointer"}} onClick={()=>setEditing(true)}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"4px 0"}}>
              <span style={{fontSize:12,color:"#ddd"}}>{match.team1||"TBD"}</span>
              {match.played && <span style={{background:"#2A398D",color:"#FFD700",borderRadius:4,padding:"1px 6px",fontWeight:900,fontSize:13}}>{match.score1}</span>}
            </div>
            <div style={{borderTop:"1px solid rgba(255,255,255,0.06)",borderBottom:"1px solid rgba(255,255,255,0.06)",padding:"2px 0",margin:"2px 0",textAlign:"center",color:"#444",fontSize:10}}>vs</div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"4px 0"}}>
              <span style={{fontSize:12,color:"#ddd"}}>{match.team2||"TBD"}</span>
              {match.played && <span style={{background:"#2A398D",color:"#FFD700",borderRadius:4,padding:"1px 6px",fontWeight:900,fontSize:13}}>{match.score2}</span>}
            </div>
          </div>
        )}
      </div>
    );
  }
  return (
    <div>
      {["r32","r16","semi","final"].map(rk => (
        <div key={rk} style={{marginBottom:20}}>
          <div style={{fontSize:13,fontWeight:900,color:"#FFD700",textTransform:"uppercase",letterSpacing:2,marginBottom:10,textAlign:"center"}}>{roundLabels[rk]}</div>
          <div style={{display:"grid",gridTemplateColumns:knockout[rk].length>1?"1fr 1fr":"1fr",gap:8}}>
            {knockout[rk].map((match,i)=><KOMatch key={i} match={match} roundKey={rk} i={i}/>)}
          </div>
        </div>
      ))}
      {knockout.champion && (
        <div style={{background:"linear-gradient(135deg,#2A398D,#E61D25)",borderRadius:16,padding:20,textAlign:"center",fontSize:20,fontWeight:900,color:"#FFD700",boxShadow:"0 0 40px rgba(255,215,0,0.3)"}}>
          🏆 {t.winner}: <strong>{knockout.champion}</strong>
        </div>
      )}
    </div>
  );
}

// ── STYLES ────────────────────────────────────────────────────────────────────
const S = {
  root:{ minHeight:"100vh", background:"#0a0e1a", color:"#fff", fontFamily:"'Trebuchet MS','Gill Sans',sans-serif", position:"relative", overflowX:"hidden" },
  bgPattern:{ position:"fixed", inset:0, background:"radial-gradient(ellipse at 20% 20%,rgba(42,57,141,0.3) 0%,transparent 50%),radial-gradient(ellipse at 80% 80%,rgba(230,29,37,0.2) 0%,transparent 50%)", pointerEvents:"none", zIndex:0 },
  notif:{ position:"fixed", top:16, left:"50%", transform:"translateX(-50%)", background:"#3CAC3B", color:"#fff", padding:"8px 24px", borderRadius:20, fontWeight:700, zIndex:9999, fontSize:13, boxShadow:"0 4px 20px rgba(0,0,0,0.4)" },
  header:{ position:"sticky", top:0, zIndex:100, background:"rgba(10,14,26,0.96)", backdropFilter:"blur(12px)", borderBottom:"1px solid rgba(255,215,0,0.12)" },
  hTop:{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"10px 14px" },
  logo:{ display:"flex", alignItems:"center", gap:9 },
  logoIcon:{ fontSize:30, filter:"drop-shadow(0 0 8px rgba(255,215,0,0.6))" },
  logoTitle:{ fontSize:16, fontWeight:900, background:"linear-gradient(90deg,#FFD700,#fff)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", letterSpacing:2 },
  logoSub:{ fontSize:9, color:"#666", letterSpacing:2, textTransform:"uppercase" },
  hCtrls:{ display:"flex", gap:7, alignItems:"center" },
  langBtn:{ background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.13)", color:"#fff", borderRadius:20, padding:"5px 11px", cursor:"pointer", fontSize:11, fontWeight:700 },
  autoBtn:{ background:"#E61D25", border:"none", color:"#fff", borderRadius:20, padding:"5px 11px", cursor:"pointer", fontSize:11, fontWeight:700 },
  resetBtn:{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.09)", color:"#aaa", borderRadius:20, padding:"5px 9px", cursor:"pointer", fontSize:13 },
  tabs:{ display:"flex", borderTop:"1px solid rgba(255,255,255,0.05)" },
  tab:{ flex:1, padding:"9px 4px", background:"transparent", border:"none", color:"#777", cursor:"pointer", fontSize:10, fontWeight:700, letterSpacing:0.4, transition:"color 0.2s" },
  tabA:{ color:"#FFD700", borderBottom:"2px solid #FFD700" },
  main:{ padding:"12px 12px 80px", maxWidth:600, margin:"0 auto", position:"relative", zIndex:1 },
  // Filter bar
  filterBar:{ display:"flex", flexDirection:"column", gap:8, marginBottom:14, background:"rgba(255,255,255,0.03)", borderRadius:12, padding:10, border:"1px solid rgba(255,255,255,0.07)" },
  filterRow:{ display:"flex", gap:6, flexWrap:"wrap" },
  filterBtn:{ background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", color:"#999", borderRadius:16, padding:"4px 12px", cursor:"pointer", fontSize:11, fontWeight:700 },
  filterBtnA:{ background:"rgba(255,215,0,0.15)", border:"1px solid #FFD700", color:"#FFD700" },
  // Date header
  dateHeader:{ display:"flex", alignItems:"center", gap:8, padding:"12px 4px 6px", fontSize:13, fontWeight:700 },
  todayBadge:{ background:"#E61D25", color:"#fff", borderRadius:6, padding:"2px 8px", fontSize:10, fontWeight:900 },
  // Calendar card
  calCard:{ background:"rgba(255,255,255,0.035)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:12, padding:"10px 12px", marginBottom:8 },
  calTop:{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8, flexWrap:"wrap", gap:4 },
  calBadge:{ borderRadius:12, padding:"2px 9px", fontSize:10, fontWeight:900 },
  calTime:{ fontSize:10, color:"#666" },
  calTeams:{ display:"flex", alignItems:"center", gap:6 },
  calTeam:{ flex:1, display:"flex", alignItems:"center", gap:5 },
  calFlag:{ fontSize:20, flexShrink:0 },
  calTeamName:{ fontSize:11, color:"#ccc", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", flex:1 },
  calScore:{ minWidth:72, textAlign:"center", flexShrink:0 },
  // Shared
  scoreDisp:{ background:"rgba(255,215,0,0.1)", border:"1px solid rgba(255,215,0,0.3)", borderRadius:7, padding:"3px 9px", fontSize:14, fontWeight:900, color:"#FFD700", display:"block" },
  sInput:{ width:36, background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,215,0,0.4)", color:"#FFD700", borderRadius:6, padding:"4px 5px", textAlign:"center", fontSize:14, fontWeight:700 },
  btnEdit:{ background:"rgba(42,57,141,0.4)", border:"1px solid rgba(42,57,141,0.6)", color:"#8ca0ff", borderRadius:12, padding:"4px 13px", cursor:"pointer", fontSize:11, fontWeight:700 },
  btnSave:{ background:"#3CAC3B", border:"none", color:"#fff", borderRadius:12, padding:"5px 14px", cursor:"pointer", fontSize:12, fontWeight:700 },
  // Groups
  groupSel:{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:12, justifyContent:"center" },
  gTab:{ width:34, height:34, borderRadius:8, border:"1px solid rgba(255,255,255,0.1)", background:"rgba(255,255,255,0.04)", color:"#aaa", cursor:"pointer", fontWeight:900, fontSize:12 },
  card:{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:14, overflow:"hidden" },
  cardH:{ padding:"10px 14px", borderBottom:"1px solid rgba(255,255,255,0.06)", display:"flex", justifyContent:"space-between", alignItems:"center" },
  cardTitle:{ fontSize:12, fontWeight:700, color:"#ddd" },
  badge:{ color:"#FFD700", padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:900 },
  table:{ width:"100%", borderCollapse:"collapse", fontSize:12 },
  th:{ padding:"7px 5px", color:"#555", fontWeight:700, textAlign:"center", borderBottom:"1px solid rgba(255,255,255,0.05)", fontSize:10, whiteSpace:"nowrap" },
  td:{ padding:"8px 5px", textAlign:"center", fontSize:11 },
  // KO
  koMatch:{ background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:10, padding:10 },
  koInput:{ background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", color:"#fff", borderRadius:6, padding:"5px 8px", fontSize:12, width:"100%", boxSizing:"border-box" },
  koDateChip:{ fontSize:10, color:"#5a6a8a", marginBottom:7, paddingBottom:5, borderBottom:"1px solid rgba(255,255,255,0.05)", letterSpacing:0.2 },
  // Group match date chip
  matchDateChip:{ display:"flex", alignItems:"center", gap:4, fontSize:10, color:"#5a6a8a", marginBottom:6, flexWrap:"wrap" },
  matchDateDot:{ width:5, height:5, borderRadius:"50%", background:"#2A398D", display:"inline-block", flexShrink:0 },
  // Stats
  statsGrid:{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12 },
  statCard:{ background:"rgba(255,255,255,0.04)", borderRadius:12, padding:14, textAlign:"center" },
  empty:{ textAlign:"center", color:"#555", padding:40, fontSize:14 },
  footer:{ textAlign:"center", padding:"14px", fontSize:9, color:"#2a2a2a", letterSpacing:2, borderTop:"1px solid rgba(255,255,255,0.03)", background:"rgba(0,0,0,0.3)" },
};
